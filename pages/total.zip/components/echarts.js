let chartLine;
let chartPie;
import * as echarts from '../../../ec-canvas/echarts';
Component({
    properties: {
        canvasId: String,
        title: {
            type: String,
            observer: function (newval, oldval) {
                this.setData({
                    title: newval
                })
            }
        },
        legendData: {
            type: Array,
            observer: function (newval, oldval) {
                this.setData({
                    legendData: newval
                })
            }
        },
        groutBy: {
            type: String,
            observer: function (newval, oldval) {
                this.setData({
                    groutBy: newval
                })
            }
        },
        colors: {
            type: Array,
            observer: function (newval, oldval) {
                this.setData({
                    colors: newval
                })
            }
        },
        lineDataX: {
            type: Array,
            observer: function (newval, oldval) {
                this.setData({
                    lineDataX: newval
                })
            }
        },
        series: {
            type: Array,
            observer: function (newval, oldval) {
                this.setData({
                    series: newval
                })
            }
        },
    },

    data: {
        ecLine: { lazyLoad: true },
        ecPie: {
            onInit: function (canvas, width, height){
                chartPie = echarts.init(canvas, null, {
                    width: width,
                    height: height
                });
                canvas.setChart(chartPie);
                var xData = [1,2,3,4,5]
                // var option = getOption(xData);
                // chartPie.setOption(option);
            }
        },
    },
    
    ready(){
        console.log(this.data)
        console.log(this.properties)
        this.init_line_echarts()
    },

    methods: {
        //初始化图表
        init_line_echarts: function () {
            this.echartsComponnetLine = this.selectComponent('#'+ this.data.canvasId);
            this.echartsComponnetLine.init((canvas, width, height) => {
                chartLine = echarts.init(canvas, null, {
                    width: width,
                    height: height
                });
                canvas.setChart(chartLine);
                var option = getLineOption(this.data.lineDataX, this.data.series,this.data.colors,this.data.title,this.data.legendData,this.data.groutBy);
                chartLine.clear();  // 清除
                chartLine.setOption(option); //加载初始数据
            })
        },
    }
})

function getLineOption(lineDataX, series, colors, title, legendData, groutBy){

    let seriesData = []
    for (let i in series) {
        seriesData.push({
            name: series[i].name,
            type: 'line',
            smooth: true,
            symbol: 'none',
            label: {
                normal: {
                    show: true,
                    position: 'inside'
                }
            },
            // markLine : {
            // 　　data : [
            // 　　　　{type : 'average', name: '平均值'}
            // 　　]
            // },
            areaStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                    offset: 0,
                    color: colors[i]
                }, {
                    offset: 1,
                    color: '#ffe'
                }])
            },
            data: series[i].series
        })
    }

    var option = {
        color: colors,
        title: {
            text: title,
            left: '3%',
            textStyle: {
                fontSize: 14,
                color: '#666',
                fontWeight: 'bold'
            }
        },
        legend: {
            data: legendData,
            // backgroundColor: '#eee',
            right: '5%'
        },
        tooltip: {
            show: true,
            trigger: 'axis',
        },
        grid: {
            left: '3%',
            right: '5%',
            bottom: '12%',
            containLabel: true
        },
        xAxis: {
            data: lineDataX,
            axisTick: {
                show: false
            },
            axisLabel: {
                formatter: function (value, index) {
                    var date = new Date(value);
                    if (groutBy == 'date') {
                        var texts = [(date.getMonth() + 1), date.getDate()];
                        return texts.join('月');
                    } else {
                        return value + '月'
                    }
                }
            },
            axisLine: {
                lineStyle: {
                    color: "#999",
                }
            },
        },
        yAxis: {
            axisTick: {
                show: false
            },
            axisLine: {
                show: false,
                lineStyle: {
                    color: "#999",
                }
            },
            splitLine: {
                lineStyle: {
                    width: 0.5,
                    type: 'dashed',
                    color: '#eee'
                }
            }
        },
        series: seriesData
    }
    return option;
}