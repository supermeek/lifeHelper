const app = getApp()
import util from '../../utils/util.js'
Page({
    data: {
        isLogin: false,
        theme: app.globalData.theme,
        lineColor: ["#04B404", "#ff0000"],
        lineDataX: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        series: [
            {name: "收入", series: [12509.71, 11004.96, 9211, 13324, 17280, 13842.78, 12514, 0, 0, 0, 0, 0]},
            {name: "支出", series: [8904.32, 5710.23, 5266.72, 7477.82, 9789.06, 7328.8, 6852.24, 431.7, 0, 0, 0, 0]}
        ],
        legendData: ["收入","支出"],
        type: 'month',
        pieColor: [],
        ec: { lazyLoad: true },
        typeList: util.typeList
    },

    onLoad: function (options) {

    },

    onShow: function () {
        app.setThemeColor()
        this.setData({ theme: app.globalData.theme })

    },

})